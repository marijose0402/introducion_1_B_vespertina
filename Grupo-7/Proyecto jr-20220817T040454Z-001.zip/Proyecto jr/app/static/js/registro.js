function agregarUsuario (){
    var nombre = document.getElementById("nombre").value;
    var apellidos = document.getElementById("apellidos").value;
    var cedula = document.getElementById("cedula").value;
    var sexo = document.querySelector(`input[name=sexo]:checked`).value;
    var fecha = document.querySelector(`input[name=fecha]`).value;
    var celular = document.getElementById("celular").value;
    var correo = document.getElementById("correo").value;
    var contraseña = document.getElementById("contraseña").value;

    var boton = document.getElementById("boton");
    var checks = document.querySelectorAll('.valores');
    var idioma = boton, checks;

    boton.addEventListener("click",function() {
        checks.forEach((elemento) => {
            if (elemento.checked == true) {
         console.log(elemento.value);
            }
        })
    });

      
  if(nombre==""){
        alert("NOMBRES,Este dato es obligatorio");  
        document.getElementById("nombre").focus();
      }
      if(apellidos==""){
        alert("APELLIODOS,Este dato es obligatorio");  
        document.getElementById("apellido").focus();
      }  
      if(cedula==""){
        alert("CEDULA,Este dato es obligatorio");  
        document.getElementById("cedula").focus();
      }
      if(sexo==" "){
        document.querySelector(`input[name=sexo]`).focus;
      }
      if(fecha==""){
        alert("FECHA,Este dato es obligatorio"); 
        document.getElementById("fecha").focus();
    }
    if(celular==""){
        alert("NUMERO CELULAR,Este dato es obligatorio"); 
        document.getElementById("celular").focus();

    }
      if(correo==""){
        alert("CORREO,Este dato es obligatorio"); 
        document.getElementById("correo").focus();   
    }
   // if(idioma==" "){
   // document.querySelector(`input[id=checks]`).focus;
    //  }
      if(contraseña==""){
        alert("NOMBRES,Este dato es obligatorio");  
        document.getElementById("contrasena").focus();
        
      }


    console.log(nombre + " " + apellidos + " " + cedula+" "+ sexo+" " + fecha+" "+celular+""+correo+""+idioma+""+contraseña);
   
  }

